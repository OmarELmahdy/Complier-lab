package csen1002.main.task3;

/**
 * Write your info here
 * 
 * @name John Smith
 * @id 43-0234
 * @labNumber 07
 */

public class RegToNFA {

	/**
	 * Constructs an NFA corresponding to a regular expression based on Thompson's
	 * construction
	 * 
	 * @param regex The regular expression in postfix notation for which the NFA is
	 *              to be constructed
	 */
	public RegToNFA(String regex) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return Returns a formatted string representation of the NFA. The string
	 *         representation follows the one in the task description
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return null;
	}

}
